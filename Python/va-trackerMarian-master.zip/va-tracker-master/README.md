## Como correrlo

### Modo Marian

* Ir al codigo y dejar tu path como default

### Modo plebe

* Correr main.py con el argumento -v o --video y el path del video

## Como funciona

* Arranca el video y tenes que seleccionar el contorno que queres que trackee

* Se dejo por default los valores para que tome el auto directamente (600px)

* Apretar la "q"

* Mirar


#### Info

* Apretar la "p" en el medio del video pausa el mismo